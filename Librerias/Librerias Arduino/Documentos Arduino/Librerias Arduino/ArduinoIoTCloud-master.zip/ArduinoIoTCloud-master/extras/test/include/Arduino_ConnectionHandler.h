/*
   Copyright (c) 2019 Arduino.  All rights reserved.
*/

#ifndef TEST_ARDUINO_CONNECTION_HANDLER_H_
#define TEST_ARDUINO_CONNECTION_HANDLER_H_

/******************************************************************************
   TYPEDEF
 ******************************************************************************/

typedef void ConnectionHandler;

#endif /* TEST_ARDUINO_CONNECTION_HANDLER_H_ */
